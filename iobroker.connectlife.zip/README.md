# ioBroker ConnectLife Adapter

This is a prototype adapter for ioBroker.