
const utils = require('@iobroker/adapter-core');
const axios = require('axios');

class ConnectLife extends utils.Adapter {
    constructor(options = {}) {
        super({
            ...options,
            name: 'connectlife',
        });
        this.on('ready', this.onReady.bind(this));
        this.on('unload', this.onUnload.bind(this));
    }

    async onReady() {
        this.log.info('ConnectLife Adapter started');

        const email = this.config.email;
        const password = this.config.password;
        const region = this.config.region;

        this.log.info(`Using email: ${email}, region: ${region}`);

        // TODO: Implement real ConnectLife API Login
        try {
            this.setState('info.connection', true, true);
        } catch (err) {
            this.log.error('Error: ' + err);
        }
    }

    onUnload(callback) {
        try {
            this.setState('info.connection', false, true);
            callback();
        } catch (e) {
            callback();
        }
    }
}

if (module.parent) {
    module.exports = (options) => new ConnectLife(options);
} else {
    new ConnectLife();
}
