
# ioBroker ConnectLife Direct (MQTT slim)

**Status:** MVP. Nutzt MQTT *connectlife/slim/* Topics und erstellt NUR die ausgewählten Datenpunkte.

## Installation (aus eigener Quelle)
1. In ioBroker Admin → Adapter → „aus eigener Quelle installieren“ → ZIP auswählen.
2. Instanz anlegen und in der Konfiguration unter „Verbindung“ **MQTT Host/Port** eintragen.
3. Unter „Datenpunkte“ auswählen, welche States erstellt/aktualisiert werden sollen.
4. Speichern & Instanz starten.

## Hinweise
- Der **Direktmodus** ist nur als Platzhalter enthalten, da die offizielle ConnectLife API nicht dokumentiert ist.
- Für produktiven Einsatz bitte **MQTT** verwenden (z.B. via bestehendem Slim-Connector).
