
"use strict";
const utils = require("@iobroker/adapter-core");
const mqtt = require("mqtt");
const axios = require("axios");

class ConnectlifeDirect extends utils.Adapter {
  constructor(options) {
    super({
      ...options,
      name: "connectlife-direct",
    });
    this.client = null;
    this.stateDefs = {
      program_name: {name: "Programmname", type: "string", role: "text"},
      program_mode: {name: "Programmmodus", type: "string", role: "text"},
      remaining_minutes: {name: "Restlaufzeit", type: "number", role: "value.time.remaining", unit: "min"},
      phase: {name: "Programmphase", type: "string", role: "text"},
      door_open: {name: "Tür offen", type: "boolean", role: "sensor.door"},
      salt_status: {name: "Salz OK", type: "boolean", role: "indicator"},
      rinse_status: {name: "Klarspüler OK", type: "boolean", role: "indicator"},
      temp_unit: {name: "Temperatur-Einheit", type: "string", role: "text"},
      availability: {name: "Verfügbarkeit", type: "string", role: "text"},
      name: {name: "Gerätename", type: "string", role: "text"}
    };
    this.enabledStates = new Set();
    this.on("ready", this.onReady.bind(this));
    this.on("unload", this.onUnload.bind(this));
  }

  async onReady() {
    try {
      const cfg = this.config;
      (cfg.enabledStates || []).forEach(s => this.enabledStates.add(s));

      if (cfg.dataSource === "direct") {
        this.log.warn("Direktmodus ist experimentell. Ohne dokumentierte API kann keine Funktion garantiert werden.");
        await this.startDirectMode();
      } else {
        await this.startMqttMode();
      }
    } catch (e) {
      this.log.error(`Startfehler: ${e.message}`);
    }
  }

  async startMqttMode() {
    const m = this.config.mqtt || {};
    const url = `mqtt://${m.host || "127.0.0.1"}:${m.port || 1883}`;
    const opts = {};
    if (m.username) opts.username = m.username;
    if (m.password) opts.password = m.password;

    this.log.info(`Verbinde MQTT ${url} ...`);
    this.client = mqtt.connect(url, opts);

    this.client.on("connect", () => {
      const prefix = (m.topicPrefix || "connectlife/slim").replace(/\/+$/,"");
      const topic = `${prefix}/#`;
      this.client.subscribe(topic, (err) => {
        if (err) this.log.error(`Subscribe-Fehler: ${err.message}`);
        else this.log.info(`Abonniert: ${topic}`);
      });
    });

    this.client.on("message", async (topic, payload) => {
      try {
        const msg = payload.toString("utf-8");
        const parts = topic.split("/");
        const idx = parts.indexOf("slim");
        if (idx < 0 || parts.length < idx + 2) return;
        const deviceId = parts[idx + 1];
        const restPath = parts.slice(idx + 2).join("/");

        const filterIDs = this.config?.mqtt?.deviceIds || [];
        if (Array.isArray(filterIDs) && filterIDs.length && !filterIDs.includes(deviceId)) return;

        const map = {
          "alias/program_name": "program_name",
          "alias/program_mode": "program_mode",
          "alias/remaining_minutes": "remaining_minutes",
          "alias/phase": "phase",
          "alias/door_open": "door_open",
          "alias/salt_status": "salt_status",
          "alias/rinse_status": "rinse_status",
          "alias/temp_unit": "temp_unit",
          "availability": "availability",
          "name": "name"
        };

        const stateKey = map[restPath];
        if (!stateKey) return;
        if (!this.enabledStates.has(stateKey)) return;

        let val = msg;
        if (stateKey === "remaining_minutes") {
          const n = parseInt(msg, 10);
          if (!isNaN(n)) val = n;
        } else if (stateKey === "door_open") {
          val = msg === "1" || msg === "true" || /^open/i.test(msg);
        } else if (stateKey === "salt_status" || stateKey === "rinse_status") {
          val = /^ok$/i.test(msg) || msg === "2" || msg === "1" ? true : false;
        }

        await this.ensureStateObjects(deviceId);

        const def = this.stateDefs[stateKey];
        await this.setObjectNotExistsAsync(`${deviceId}.${stateKey}`, {
          type: "state",
          common: {name: def.name, type: def.type, read: true, write: false, role: def.role, unit: def.unit},
          native: {}
        });
        await this.setStateAsync(`${deviceId}.${stateKey}`, { val, ack: true });
      } catch (e) {
        this.log.warn(`Verarbeitungsfehler für ${topic}: ${e.message}`);
      }
    });

    this.client.on("error", (err) => {
      this.log.error(`MQTT-Fehler: ${err.message}`);
    });
  }

  async ensureStateObjects(deviceId) {
    await this.setObjectNotExistsAsync(deviceId, {
      type: "device",
      common: { name: deviceId },
      native: {}
    });
    await this.setObjectNotExistsAsync(`${deviceId}.status`, {
      type: "channel",
      common: { name: "Status" },
      native: {}
    });
  }

  async startDirectMode() {
    this.log.warn("Direktmodus nicht implementiert. Bitte 'MQTT' als Datenquelle verwenden.");
  }

  onUnload(callback) {
    try {
      if (this.client) {
        this.client.end(true);
      }
      callback();
    } catch (e) {
      callback();
    }
  }
}

if (module.parent) {
  module.exports = (options) => new ConnectlifeDirect(options);
} else {
  new ConnectlifeDirect();
}
